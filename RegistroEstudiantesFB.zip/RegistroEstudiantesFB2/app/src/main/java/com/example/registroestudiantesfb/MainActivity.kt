package com.example.registroestudiantesfb

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import android.content.Intent

class MainActivity : AppCompatActivity() {

    private lateinit var txtNombre: EditText
    private lateinit var txtCarrera: EditText
    private lateinit var txtCurso: EditText
    private lateinit var btnGuardar: Button

    private lateinit var btnVer: Button

    private lateinit var estudiantesRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        estudiantesRef = FirebaseDatabase.getInstance()
            .getReference("Estudiantes")

        txtNombre = findViewById(R.id.txtNombre)
        txtCarrera = findViewById(R.id.txtCarrera)
        txtCurso = findViewById(R.id.txtCurso)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnVer = findViewById(R.id.btnVer)

        btnVer.setOnClickListener {

            startActivity(
                Intent(
                    this,
                    ListaEstudiantesActivity::class.java
                )
            )
        }

        btnGuardar.setOnClickListener {
            guardarEstudiante()
        }
    }

    private fun guardarEstudiante() {

        val nombre = txtNombre.text.toString().trim()
        val carrera = txtCarrera.text.toString().trim()
        val curso = txtCurso.text.toString().trim()

        if (nombre.isEmpty() || carrera.isEmpty() || curso.isEmpty()) {

            Toast.makeText(
                this,
                "Complete todos los campos",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        val id = estudiantesRef.push().key ?: return

        val estudiante = Estudiante(
            id,
            nombre,
            carrera,
            curso
        )

        estudiantesRef.child(id)
            .setValue(estudiante)
            .addOnSuccessListener {

                Toast.makeText(
                    this,
                    "Estudiante registrado",
                    Toast.LENGTH_LONG
                ).show()

                txtNombre.text.clear()
                txtCarrera.text.clear()
                txtCurso.text.clear()
            }

            .addOnFailureListener {

                Toast.makeText(
                    this,
                    "Error al guardar",
                    Toast.LENGTH_LONG
                ).show()
            }
    }
}
