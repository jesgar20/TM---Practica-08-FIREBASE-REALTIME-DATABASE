package com.example.registroestudiantesfb

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EstudianteAdapter(
    private val lista: ArrayList<Estudiante>,
    private val listener: OnItemClickListener
) : RecyclerView.Adapter<EstudianteAdapter.ViewHolder>() {

    interface OnItemClickListener {
        fun onItemClick(estudiante: Estudiante)
    }

    class ViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val txtNombre: TextView =
            itemView.findViewById(R.id.txtNombreItem)

        val txtCarrera: TextView =
            itemView.findViewById(R.id.txtCarreraItem)

        val txtCurso: TextView =
            itemView.findViewById(R.id.txtCursoItem)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_estudiante, parent, false)

        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return lista.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val estudiante = lista[position]

        holder.txtNombre.text = estudiante.nombre
        holder.txtCarrera.text = estudiante.carrera
        holder.txtCurso.text = estudiante.curso

        holder.itemView.setOnClickListener {
            listener.onItemClick(estudiante)
        }
    }
}