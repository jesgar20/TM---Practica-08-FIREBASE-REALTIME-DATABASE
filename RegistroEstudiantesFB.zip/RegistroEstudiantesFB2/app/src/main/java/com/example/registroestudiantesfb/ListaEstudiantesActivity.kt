package com.example.registroestudiantesfb

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class ListaEstudiantesActivity :
    AppCompatActivity(),
    EstudianteAdapter.OnItemClickListener {

    private lateinit var recycler: RecyclerView

    private lateinit var lista: ArrayList<Estudiante>

    private lateinit var adapter: EstudianteAdapter

    private lateinit var estudiantesRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_lista_estudiantes)

        recycler = findViewById(R.id.recyclerEstudiantes)

        recycler.layoutManager = LinearLayoutManager(this)

        lista = ArrayList()

        adapter = EstudianteAdapter(lista, this)

        recycler.adapter = adapter

        estudiantesRef = FirebaseDatabase.getInstance()
            .getReference("Estudiantes")

        leerDatos()
    }

    private fun leerDatos() {

        estudiantesRef.addValueEventListener(object :
            ValueEventListener {

            override fun onDataChange(snapshot: DataSnapshot) {

                lista.clear()

                for (dato in snapshot.children) {

                    val estudiante =
                        dato.getValue(Estudiante::class.java)

                    if (estudiante != null) {

                        lista.add(estudiante)
                    }
                }

                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {

            }
        })
    }

    override fun onItemClick(estudiante: Estudiante) {

        val opciones = arrayOf(
            "Actualizar",
            "Eliminar"
        )

        AlertDialog.Builder(this)
            .setTitle("Seleccione opción")
            .setItems(opciones) { _, which ->

                when (which) {

                    0 -> mostrarDialogoActualizar(estudiante)

                    1 -> eliminarEstudiante(estudiante)
                }
            }
            .show()
    }

    private fun mostrarDialogoActualizar(
        estudiante: Estudiante
    ) {

        val view = layoutInflater.inflate(
            R.layout.dialog_actualizar,
            null
        )

        val txtNombre =
            view.findViewById<EditText>(R.id.editNombre)

        val txtCarrera =
            view.findViewById<EditText>(R.id.editCarrera)

        val txtCurso =
            view.findViewById<EditText>(R.id.editCurso)

        txtNombre.setText(estudiante.nombre)
        txtCarrera.setText(estudiante.carrera)
        txtCurso.setText(estudiante.curso)

        AlertDialog.Builder(this)
            .setTitle("Actualizar")
            .setView(view)

            .setPositiveButton("Guardar") { _, _ ->

                val datos = HashMap<String, Any>()

                datos["nombre"] =
                    txtNombre.text.toString()

                datos["carrera"] =
                    txtCarrera.text.toString()

                datos["curso"] =
                    txtCurso.text.toString()

                estudiantesRef.child(estudiante.id)
                    .updateChildren(datos)

                Toast.makeText(
                    this,
                    "Actualizado",
                    Toast.LENGTH_SHORT
                ).show()
            }

            .setNegativeButton("Cancelar", null)

            .show()
    }

    private fun eliminarEstudiante(
        estudiante: Estudiante
    ) {

        estudiantesRef.child(estudiante.id)
            .removeValue()

        Toast.makeText(
            this,
            "Eliminado",
            Toast.LENGTH_SHORT
        ).show()
    }
}